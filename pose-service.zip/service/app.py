"""pose-service — renders clay pose references on CPU, no GPU and no pod required.

Loads Blender as a Python module once at boot. Every render reopens the mannequin
fresh (~0.05s), so no pose state can leak from one render into the next.

THREADING — the reason the endpoints are `async def`: FastAPI runs plain `def`
endpoints in a worker thread pool, and Blender's operators must run on the MAIN thread.
Calling bpy.ops.wm.open_mainfile from a pool thread killed the whole process on the
first test. An `async def` endpoint runs on uvicorn's event-loop thread, which is the
main thread with a single worker, and because each render blocks the loop until it
finishes, renders are also serialised for free. Run with ONE worker, never more.

The posing, landmarks, camera and shading all come from render_pose.py, imported as a
module — the same file the command line uses — so the CLI and the service cannot
drift apart.
"""

import base64
import contextlib
import io
import os
import re
import tempfile
import time

import bpy  # noqa: F401  (imported once; must precede render_pose)
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

import render_pose as rp

BLEND = os.environ.get("MANNEQUIN_BLEND", os.path.join(os.path.dirname(__file__),
                                                       "lysa-mannequin-v1.blend"))
SECRET = os.environ.get("POSE_SERVICE_SECRET", "")
MAX_SPECS = 12

app = FastAPI(title="pose-service", version="1.0")


class Spec(BaseModel):
    yaw: float = 0.0
    pitch: float = 0.0
    roll: float = 0.0
    torso: float = 0.0
    arms: float = 35.0
    crop: str = "chest"
    lens: float = 50.0
    span: float | None = None
    centre: float | None = None
    width: int = 1024
    height: int = 1536
    name: str | None = None


class Batch(BaseModel):
    specs: list[Spec] = Field(min_length=1)


def default_name(s: Spec) -> str:
    parts = [f"y{s.yaw:g}"]
    for key, val in (("p", s.pitch), ("r", s.roll), ("t", s.torso)):
        if val:
            parts.append(f"{key}{val:g}")
    if s.arms != 35.0:
        parts.append(f"a{s.arms:g}")
    parts.append(s.crop)
    return re.sub(r"[^A-Za-z0-9_.-]", "", "_".join(parts).replace("-", "m"))


def render_one(s: Spec) -> dict:
    if s.crop not in rp.CROPS:
        raise ValueError(f"unknown crop {s.crop!r}; choose from {sorted(rp.CROPS)}")
    log = io.StringIO()
    started = time.monotonic()
    with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(log):
        bpy.ops.wm.open_mainfile(filepath=BLEND)          # clean state every time
        arm = rp.find_armature()
        if s.torso:
            import math
            arm.rotation_euler = (0.0, 0.0, math.radians(-s.torso))
        rp.pose_head(arm, s.yaw, s.pitch, s.roll)
        rp.lower_arms(arm, s.arms)
        bpy.context.view_layer.update()
        zmin, zmax = rp.figure_bounds()
        lm = rp.landmarks(arm, zmin, zmax)
        rp.setup_camera(s.crop, s.lens, lm, override_span=s.span,
                        override_centre=s.centre)
        rp.setup_workbench(s.width, s.height)
        out = os.path.join(tmp, "r.png")
        bpy.context.scene.render.filepath = out
        bpy.ops.render.render(write_still=True)
        png = open(out, "rb").read()
    lines = [l.strip() for l in log.getvalue().splitlines() if l.strip()]
    return {
        "name": s.name or default_name(s),
        "params": s.model_dump(exclude={"name"}),
        "info": lines,
        "seconds": round(time.monotonic() - started, 2),
        "png_b64": base64.b64encode(png).decode(),
    }


@app.get("/health")
async def health():
    return {"ok": True, "blender": bpy.app.version_string,
            "mannequin": os.path.basename(BLEND),
            "mannequin_exists": os.path.exists(BLEND), "crops": sorted(rp.CROPS)}


@app.post("/render")
async def render(batch: Batch, x_pose_key: str | None = Header(default=None)):
    if SECRET and x_pose_key != SECRET:
        raise HTTPException(401, "bad or missing X-Pose-Key")
    if len(batch.specs) > MAX_SPECS:
        raise HTTPException(400, f"max {MAX_SPECS} poses per batch")
    results, errors = [], []
    for i, s in enumerate(batch.specs):
        try:
            results.append(render_one(s))
        except Exception as e:      # one bad spec must not sink the batch
            errors.append({"index": i, "error": f"{type(e).__name__}: {e}"})
    return {"results": results, "errors": errors}
