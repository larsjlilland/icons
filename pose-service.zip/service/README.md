# pose-service

Renders clay pose references for the IceValkyrja pipeline on CPU. No GPU and no pod:
Blender runs as a Python module and Mesa's software rasteriser draws the frame.

Verified 2026-10-02 in a GPU-less, single-core container against the real mannequin:
output pixel-identical to running render_pose.py directly, ~2s per render, and within
1/255 of the Mac and pod renders.

## Endpoints
GET  /health   -> blender version, mannequin present, crops
POST /render   {"specs":[{"yaw":45,"crop":"chest"}, ...]}   header X-Pose-Key
     -> {"results":[{name, params, info[], seconds, png_b64}], "errors":[...]}
Max 12 specs per call. A bad spec is reported in "errors" without sinking the batch.

## Deploy (Railway)
1. New PRIVATE GitHub repo "pose-service" containing this folder.
2. Railway: New Service -> from that repo. The Dockerfile is picked up automatically.
3. Variables: POSE_SERVICE_SECRET = any long random string.
4. Settings -> Networking -> Generate Domain.
5. Check: curl https://<domain>/health   (must show "mannequin_exists": true)
6. Then a REAL render — /health passing does not prove the GL stack works:
     curl -s -X POST https://<domain>/render -H "Content-Type: application/json" -H "X-Pose-Key: <secret>" -d '{"specs":[{"yaw":45}]}' | head -c 300
7. vault-pilot variables: POSE_SERVICE_URL = https://<domain>, POSE_SERVICE_SECRET = same.

## Rules
- ONE worker. Blender operators must run on the main thread; the endpoints are async
  def precisely so they do. A plain def endpoint crashed the process on first render.
- render_pose.py here is the canonical copy. The Mac and pod copies should match it.
- The mannequin is apparatus: a changed hash means references are no longer
  reproducible.
