"""Render one clay reference at an exact pose.

    blender -b lysa-mannequin-v1.blend -P render_pose.py -- --yaw 45 --crop chest \
        --out ~/posegen/clay_A45.png

Output is a flat grey clay image, NOT a depth map. It goes through the pipeline's own
DepthAnythingV2 preprocessor exactly as a photographic reference does — the rig supplies
geometry, the existing preprocessor supplies the depth distribution the ControlNet was
trained on. Exporting Blender's z-pass instead is a known trap: it is metric and linear
where these ControlNets expect MiDaS-style relative depth.

Angles are degrees. Positive yaw turns the head toward the RIGHT EDGE OF THE FRAME —
frame-relative, because "camera's right" and "her right" is the ambiguity that flipped
an earlier test. Axis and sign for both head and arms were found by rendering, not
derived: head yaw is bone-local Y, arms are bone-local Z, negative on the left.
"""

import argparse
import math
import sys

import bpy

# Crops are defined by BODY LANDMARKS, not by fractions of stature. Fraction-based
# presets missed repeatedly because this mesh does not follow textbook proportions —
# the macro settings reshaped the torso, putting the nipple at z 1.103 where standard
# fractions predicted 1.194. Bone positions cannot be wrong that way, and they stay
# correct if the body is rebuilt with different macro settings.
#
# (bottom landmark, headroom above the crown in metres)
CROPS = {
    # Anchored to the collarbone, not the chin: at the close range a head crop needs,
    # the face sits ~0.1m nearer the lens and magnifies ~20%, so a chin-anchored band
    # showed only the crown and eyes (service test, 2026-10-02).
    "head":   ("neck_base", 0.05),
    "chest":  ("sternum", 0.04),
    "waist":  ("navel",   0.04),
    "hip":    ("hip",     0.04),
    "full":   ("feet",    0.06),
}

# The rendered frame cuts higher than the computed band because the body's front
# surface sits nearer the lens than the axis the maths uses. Measured from the waist
# render of 2026-09-30: with a bottom edge asked for at 0.985, the frame put the nipple
# (bone z 1.103) at 89% of frame height, implying the visible band runs ~8% short.
# One correction here rather than a fudge per crop.
PERSPECTIVE_SLACK = 1.08

HEAD_BONE_CANDIDATES = ("head", "Head", "DEF-head", "spine.006", "neck_02")
ARM_BONE_CANDIDATES = ("upperarm01", "upperarm02", "upperarm", "arm01", "shoulder01")


def cli() -> argparse.Namespace:
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument("--yaw", type=float, default=0.0)
    p.add_argument("--pitch", type=float, default=0.0)
    p.add_argument("--roll", type=float, default=0.0)
    p.add_argument("--torso", type=float, default=0.0,
                   help="degrees the whole figure turns; 0 keeps the body square")
    p.add_argument("--arms", type=float, default=35.0,
                   help="degrees to lower the upper arms from the rest pose")
    p.add_argument("--crop", choices=sorted(CROPS), default="chest")
    p.add_argument("--lens", type=float, default=50.0)
    p.add_argument("--width", type=int, default=1024)
    p.add_argument("--height", type=int, default=1536)
    p.add_argument("--span", type=float, default=None,
                   help="override the crop's vertical coverage, in metres")
    p.add_argument("--centre", type=float, default=None,
                   help="override the camera height, as a fraction of figure height")
    p.add_argument("--dump-bones", action="store_true",
                   help="print every bone name and exit, rendering nothing")
    p.add_argument("--out", required=True)
    return p.parse_args(argv)


def find_armature():
    for o in bpy.data.objects:
        if o.type == "ARMATURE":
            return o
    sys.exit("no armature in the .blend — the mannequin must be rigged")


def find_head(arm):
    for name in HEAD_BONE_CANDIDATES:
        if name in arm.pose.bones:
            return arm.pose.bones[name]
    sys.exit("no head bone found. Bones present: "
             + ", ".join(b.name for b in arm.pose.bones))


def pose_head(arm, yaw, pitch, roll) -> None:
    bone = find_head(arm)
    bone.rotation_mode = "XYZ"
    # BONE SPACE. A head bone points up its own local Y, so local X is pitch,
    # local Y is yaw, local Z is roll.
    bone.rotation_euler = (math.radians(pitch), math.radians(yaw), math.radians(roll))


def lower_arms(arm, degrees: float) -> None:
    """Bring the arms down from the rest pose, which holds them out."""
    if not degrees:
        return
    found = []
    for side, sign in (("L", -1.0), ("R", 1.0)):
        for base in ARM_BONE_CANDIDATES:
            name = f"{base}.{side}"
            if name in arm.pose.bones:
                b = arm.pose.bones[name]
                b.rotation_mode = "XYZ"
                b.rotation_euler = (0.0, 0.0, math.radians(degrees) * sign)
                found.append(name)
                break
    if found:
        print(f"  arms lowered {degrees} degrees using {found}")
    else:
        print("  WARNING: no upper-arm bones matched — arms left in the rest pose")


def figure_bounds():
    """World-space Z extent of every mesh."""
    zs = []
    for o in bpy.data.objects:
        if o.type == "MESH":
            zs += [(o.matrix_world @ v.co).z for v in o.data.vertices]
    if not zs:
        sys.exit("no mesh found in the .blend")
    return min(zs), max(zs)


def landmarks(arm, zmin: float, zmax: float) -> dict:
    """Real heights on THIS body, read from the skeleton.

    Bone HEADS are used rather than tails: a bone's head sits at its joint, which is
    the anatomical point a crop should reference.
    """
    def bone_z(name: str):
        b = arm.pose.bones.get(name)
        return None if b is None else (arm.matrix_world @ b.head).z

    lm = {
        "crown": zmax,
        "feet": zmin,
        "chin": bone_z("jaw"),
        "neck_base": bone_z("clavicle.L"),
        "sternum": bone_z("spine02"),
        "navel": bone_z("spine04"),
        "hip": bone_z("pelvis.L") or bone_z("root"),
    }
    # Spine numbering direction differs between rigs, so check rather than trust:
    # the navel anchor must sit below the sternum anchor.
    if lm["sternum"] and lm["navel"] and lm["sternum"] < lm["navel"]:
        lm["sternum"], lm["navel"] = lm["navel"], lm["sternum"]
        print("  NOTE: spine bones run upward on this rig; sternum/navel swapped")
    print("  landmarks: " + ", ".join(
        f"{k} {v:.3f}" for k, v in lm.items() if v is not None))
    missing = [k for k, v in lm.items() if v is None]
    if missing:
        print(f"  WARNING: no bone found for {missing} — those crops will fail")
    return lm


def setup_camera(crop: str, lens: float, lm: dict,
                 override_span=None, override_centre=None):
    cam_data = bpy.data.cameras.new("ref_cam")
    cam_data.lens = lens
    # Blender's AUTO sensor fit applies sensor_width to the LARGER dimension, which on
    # a portrait render is the vertical one. Pin it so the maths matches the camera.
    cam_data.sensor_fit = "VERTICAL"
    cam_data.sensor_height = 24.0
    cam = bpy.data.objects.new("ref_cam", cam_data)
    bpy.context.collection.objects.link(cam)

    bottom_name, headroom = CROPS[crop]
    bottom = lm.get(bottom_name)
    if bottom is None:
        sys.exit(f"crop {crop!r} needs the {bottom_name!r} landmark, not found")
    top = lm["crown"] + headroom
    z = (top + bottom) / 2
    span = (top - bottom) * PERSPECTIVE_SLACK

    if override_centre is not None:
        z = lm["feet"] + override_centre * (lm["crown"] - lm["feet"])
    if override_span is not None:
        span = override_span

    vfov = 2 * math.atan(cam_data.sensor_height / (2 * lens))
    dist = (span / 2) / math.tan(vfov / 2)

    print(f"  crop {crop!r}: {bottom_name} {bottom:.3f} to crown+{headroom} {top:.3f}")
    print(f"  camera z {z:.3f} at {dist:.3f}m, {lens}mm, covering {span:.3f}m")
    print(f"  visible band: {z - span / 2:.3f}m to {z + span / 2:.3f}m")

    cam.location = (0.0, -dist, z)
    cam.rotation_euler = (math.radians(90), 0.0, 0.0)    # level, no tilt
    bpy.context.scene.camera = cam
    return cam


def setup_workbench(w: int, h: int) -> None:
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x, scene.render.resolution_y = w, h
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"

    sh = scene.display.shading
    sh.light = "STUDIO"          # soft shading; FLAT would give a bare silhouette
    sh.color_type = "SINGLE"     # ignore materials entirely
    sh.single_color = (0.55, 0.55, 0.55)
    # Each of these adds edges a depth estimator would read as structure.
    for attr, value in (("show_cavity", False), ("show_shadows", False),
                        ("show_object_outline", False),
                        ("show_specular_highlight", False)):
        if hasattr(sh, attr):
            setattr(sh, attr, value)

    world = scene.world or bpy.data.worlds.new("World")
    scene.world = world
    world.color = (0.18, 0.18, 0.18)     # clearly darker than the body
    scene.view_settings.view_transform = "Standard"   # no tone mapping of the greys


def main() -> None:
    args = cli()
    arm = find_armature()

    if args.dump_bones:
        print(f"=== {len(arm.pose.bones)} bones in {arm.name} ===")
        for b in arm.pose.bones:
            print(" ", b.name)
        return

    if args.torso:
        arm.rotation_euler = (0.0, 0.0, math.radians(-args.torso))
    pose_head(arm, args.yaw, args.pitch, args.roll)
    lower_arms(arm, args.arms)

    bpy.context.view_layer.update()
    zmin, zmax = figure_bounds()
    lm = landmarks(arm, zmin, zmax)
    setup_camera(args.crop, args.lens, lm,
                 override_span=args.span, override_centre=args.centre)
    setup_workbench(args.width, args.height)

    bpy.context.scene.render.filepath = bpy.path.abspath(args.out)
    bpy.ops.render.render(write_still=True)
    print(f"wrote {args.out}  yaw={args.yaw} pitch={args.pitch} roll={args.roll} "
          f"torso={args.torso} arms={args.arms} crop={args.crop} lens={args.lens}mm")


if __name__ == "__main__":
    main()
